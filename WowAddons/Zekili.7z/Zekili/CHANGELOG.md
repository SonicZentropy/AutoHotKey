# Zekili

## [v11.1.0-1.0.4](https://github.com/Zekili/zekili/tree/v11.1.0-1.0.4) (2025-03-04)
[Full Changelog](https://github.com/Zekili/zekili/compare/v11.1.0-1.0.3...v11.1.0-1.0.4) [Previous Releases](https://github.com/Zekili/zekili/releases)

- Merge pull request #4464 from johnnylam88/fix/ar-vdh-priority  
    Fixes for Aldrachi Reaver Vengeance DH  
- Merge pull request #4466 from syrifgit/syrif-priest  
    Shadow Priest APL Update + more cycling support  
- Merge pull request #4468 from syrifgit/shaman  
    Enhance shaman surging totem + TWW mythic+ affix auras  
- Merge pull request #4471 from baaron666/fix-warrior-protection  
    Fix Warrior Protection  
- Fix protection warrior  
- Fix Warrior Protection  
- Enhance shaman surging totem  
- Shadow Priest APL Update  
- chore: regenerate default vengeance demon hunter action pack  
- fix: move a variable definition to fix a warning  
- fix: add fallthrough actions for AR VDH after Reaver's Glaive  
    The APL expects that you won't make a mistake when casting the correct  
    sequence of spells after Reaver's Glaive, but mistakes happen. Add some  
    fallthrough actions to catch these mistakes and keep the rotation going.  
- fix: restore "ar\_execute" but only for boss fights  
    Allow `ar_execute` action list to be called, but only for boss fights.  
    This is an alternative way to solve #4441 as discussed with @Zekili.  
- Affliction APL  
- 11.1 Items  
- Merge pull request #4460 from johnnylam88/fix/ar-vdh-fiery-brand-usage  
    Fix for #4441  
- Warlock APLs  
- Merge pull request #4450 from johnnylam88/fix/demonhunter-tww2-fixes  
    Demon Hunter fixes and improvements  
- Merge branch 'thewarwithin' into fix/demonhunter-tww2-fixes  
- Merge pull request #4452 from syrifgit/syrif-mage  
    Fire Mage season 2 APL  
- Merge pull request #4454 from syrifgit/syrif-evoker  
    Devastation APL update  
- Merge pull request #4455 from syrifgit/syrif-march-4-patch-notes  
    March 4 patch notes  
- Merge pull request #4458 from johnnylam88/feat/simc-usable-in  
    feat: add new SimC expression "action.<spell>.usable\_in"  
- Merge pull request #4456 from syrifgit/syrif-priest  
    Shadow Priest: Support force\_devour\_matter  
- Merge pull request #4459 from johnnylam88/fix/havoc-dh-priority  
    fix: update havoc DH priority to SimC 20250301  
- chore: regenerate default vengeance DH action pack  
- fix: don't call `ar_execute` action list  
    Fixes #4441.  
- chore: regenerate havoc demon hunter default action pack  
- Change support method to metatable  
    Metatable was already built, might as well use it to avoid needing to change the syntax at all. Tested in-game.  
- fix: update havoc demon hunter priority to SimC from 20250301  
- feat: add new SimC expression "action.<spell>.usable\_in"  
    `simc:engine/action/action.cpp` implements `usable_in` as equivalent to  
    the cooldown remaining of the action.  
- Shadow Priest: Support force\_devour\_matter  
    Fixes #4449  
    Tested in-game  
- March 4 patch notes  
    all necessary adjustments for tuesdays notes: https://www.wowhead.com/news/beast-mastery-updated-season-2-class-tuning-incoming-march-4th-375381  
- Devastation APL update  
- Fire Mage season 2 APL  
    Includes a typo fix for hyperthread wristwraps that was discovered during in-game test.  
- fix: apply thrill\_of\_the\_fight\_damage if Aldrachi Reaver  
- fix: apply and pending Demonsurge buff gains immediately  
    The Demonsurge buff does not get applied for about 0.5s, but pretend it  
    happens immediately so that calculations for the next recommendation  
    will be correct right away.  
- refactor: use loops instead of hardcoding each demonsurge ability  
- fix: don't overwrite death\_sweep cooldown with wrong value  
    Set the cooldown of `blade_dance` to match `death_sweep` before  
    invoking the blade\_dance.handler()` which does the opposite.  
- fix: Blade Dance can apply Deflecting Dance  
- fix: the Demonsurge buff is removed when Metamorphosis is cast  
- fix: synchronize Metamorphosis code with Vengeance model  
    Copy code from Vengeance model to handle Metamorphosis with Demonsurge.  
    This introduces `demonsurge_hardcast` to Havoc and tracks it properly to  
    check for when various spells should be empowered.  
    Be more accurate with adding stacks of Demonsurge only when talented  
    into Demonic Intensity. This mirrors how the buff is handled in the  
    Vengeance model.  
    Fix the shared cooldowns for `eye_beam` and `abyssal_gaze`.  
    Fix the amount of haste granted by Metamorphosis.  
- fix: vengeance demon hunters don't gain haste from Metamorphosis  
- fix: settings cleanup for havoc demon hunter  
- fix: simplify sigil handling for demon hunter specs  
    A sigil is essentially a projectile spell where you select the impact  
    point, and after a travel time (sigil activation time), the projectile  
    lands and triggers impact effects.  
    Model sigils using the existing projectile spell code, where  
    `flightTime` is the constant sigil activation time and create `impact`  
    handlers to update the state machine once the sigil activates.  
    This allows us to remove all of the custom handling in `reset_precast`  
    to try to figure out when sigil debuffs are applied, and also remove the  
    `advance_end` hook function that attempted to figure out when Sigil of  
    Flame would activate.  
    Synchronize the sigil modeling between Havoc and Vengeance and correct  
    some cooldowns and spell IDs.  
- Merge pull request #4448 from syrifgit/syrif-hunter  
- Merge pull request #4443 from syrifgit/syrif-evoker  
- MM Hunter Fix  
- Aug Evoker Season 2 APL  
- Merge pull request #4442 from syrifgit/syrif-small-fixes-1  
    Surv hunter typo  
- Balance APL  
- Merge branch 'Zekili:thewarwithin' into syrif-small-fixes-1  
- Surv hunter typo  
