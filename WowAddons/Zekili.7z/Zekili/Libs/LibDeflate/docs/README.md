# Auto Generated documentation

## Read the documentation

[https://safeteewow.github.io/LibDeflate](https://safeteewow.github.io/LibDeflate)

## Write the documenation

See [config.ld](config.ld) in this folder to see the files included in the documentation.

Majority of the documents is written as the comment in LibDeflate.lua

Read the doc of [LDoc](https://stevedonovan.github.io/ldoc/manual/doc.md.html) for the comment syntax.

## Publish

The auto generated documentation is not stored in the "main" branch.
It is released to the "gh-pages" branch of this repository. This is done
automatically using the github workflow .github/workflows/make_release_and_gh_pages

## Helper script

Use tools/gen_doc.sh to generate doc.
