# Zekili

## [v11.0.0-1.0.1](https://github.com/Zekili/hekili/tree/v11.0.0-1.0.1) (2024-08-05)
[Full Changelog](https://github.com/Zekili/hekili/compare/v11.0.0-1.0.0e...v11.0.0-1.0.1) [Previous Releases](https://github.com/Zekili/hekili/releases)

- Affliction: Tweak trinket usage  
- Streamline Death Knight priorities  
- Streamline Demon Hunter priorities; fix priority versioning  
- Streamline Feral, Resto Druid priorities  
- Streamline Devastation priority  
- Streamline Hunter priorities  
- Streamline Mage priorities; sim updates  
- Holy Paladin tweaks  
- Holy, Retribution priority adjustments  
- Streamline Shadow priority  
- Streamline Rogue priorities  
- Streamline Shaman priorities  
- Warrior buffs  
- Affliction: Unstable Affliction fix  
- Flag opener talents for hero trees  
- Iterate on hero\_tree.  
- Globals  
- Demo: Adjust APL for TWW cooldown timings  
- Filter targets when GetRange is invalid  
