# hekili
This priority helper supports all DPS and Tank specializations in World of Warcraft **Retail**.

[Latest Release](https://github.com/Zekili/hekili/releases/latest)
