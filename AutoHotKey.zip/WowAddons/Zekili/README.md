# zekili
This priority helper supports all DPS and Tank specializations in World of Warcraft **Retail**.

[Latest Release](https://github.com/Zekili/zekili/releases/latest)
